const User = require('./models/user');
const Ticket = require('./models/ticket');
const Asigned = require('./models/asigned');

module.exports = (app, passport) => {

    // index route
    app.get('/', (req, res) => { 
      res.render('index');
    });

    //login view
    app.get('/login', (req,res) => { 
        res.render('login', {
            message: req.flash('loginMessage')
        });
    });

    //default sessions
    app.post('/login',passport.authenticate('login', {	
      failureRedirect: '/login',
      failureFlash: true
    }), (req, res) => { if (req.user.role === 'user') {
        res.redirect('/profile');
      }else{
        if (req.user.role === 'admin'){
          res.redirect('/admin');
        }
        res.redirect('/tech')
      }
    });

    // signup view
    app.get('/signup', (req,res) => {
        res.render('signup', {
            message: req.flash('signupMessage')
        });
    });

    app.post('/signup', passport.authenticate('signup', {
      successRedirect: '/login',
      failureRedirect: '/signup',
      failureFlash: true // allow flash messages
    }));
    
    //profile view
	app.get('/profile', isLoggedIn, (req, res) => {
		res.render('profile', {
      user: req.user,
      role: req.role
		});
  });
    
    //generate ticket
  app.get('/ticket', isLoggedIn, (req, res) => {
		res.render('ticket', {
			user: req.user
		});
  });

    //chatbot
  app.get('/chatbot', isLoggedIn, (req, res) => {
		res.render('chatbot', {
			user: req.user
		});
  });

  //admin
  app.get('/admin', isLoggedIn, (req, res) => {
    res.render('admin', {
      user: req.user
    });
  });

  //usersTable
  app.get('/tablaUsuarios', isLoggedIn, async (req, res) => {
    const users =  await User.find();
    res.render('tablaUsuarios', {
      user: req.user,
      users : users
    });
  });

  app.post('/tablaUsuarios', isLoggedIn, passport.authenticate('tablaUsuarios', {
    successRedirect: '/tablaUsuarios',
    failureFlash: true // allow flash messages
  }));


  app.get('/editUser/:id', isLoggedIn, async (req, res) => {
    const {id} = req.params;
    const user = await User.findById(id);
    res.render('editUser', {
      user
    });
  });

  app.post('/editUser/:id', isLoggedIn, async (req, res) => {
    const {id} = req.params;
    await User.update({_id: id}, req.body);
    res.redirect('/tablaUsuarios');
  });

  app.get('/deleteUser/:id', isLoggedIn, async(req, res) => {
    const {id} = req.params;
    await User.remove({_id: id});
    res.redirect('/tablaUsuarios');
  });

  //ticketsTable
  app.get('/tablaTickets', isLoggedIn, async (req, res) => {
    const tickets =  await Ticket.find();
    res.render('tablaTickets', {
      user: req.user,
      tickets: tickets
    });
  });

  app.post('/tablaTickets', isLoggedIn, async (req, res) => {
    const tickets =  new Ticket(req.body);
    tickets.save();
    res.redirect('/tablaTickets');
    console.log(req.body)
    console.log(res.body)
  });

  app.get('/editTicket/:id', isLoggedIn, async (req, res) => {
    const {id} = req.params;
    const ticket = await Ticket.findById(id);
    res.render('editTicket', {
      ticket
    });
  });

  app.post('/editTicket/:id', isLoggedIn, async (req, res) => {
    const {id} = req.params;
    await Ticket.update({_id: id}, req.body);
    res.redirect('/tablaTickets');
  });

  app.get('/deleteTicket/:id', isLoggedIn, async(req, res) => {
    const {id} = req.params;
    await Ticket.remove({_id: id});
    res.redirect('/tablaTickets');
  });

  //ticketView
  app.post('/crearTicket', isLoggedIn, async (req, res) => {
    const ticket =  new Ticket(req.body);
    await ticket.save();
    res.redirect('/ticket');
  });

  app.get('/seguimiento', isLoggedIn, async (req, res) => {
    const tickets =  await Ticket.find();
    res.render('seguimiento', {
      user: req.user,
      tickets : tickets
    });
  });

  //asignedTable
  app.get('/tablaAsignacion', isLoggedIn, async (req, res) => {
    const asigneds = await Asigned.find();
    const users = await User.find();
    const tickets = await Ticket.find();
    res.render('tablaAsignacion', {
      user: req.user,
      asigneds: asigneds,
      tickets: tickets,
      users: users
    });
  });

  app.post('/crearAsignacion', isLoggedIn, async (req, res) => {
    const asigneds =  new Asigned(req.body);
    await asigneds.save();
    res.redirect('/tablaAsignacion');
  });

  app.get('/editAsignacion/:id', isLoggedIn, async (req, res) => {
    const {id} = req.params;
    const asigned = await Asigned.findById(id);
    res.render('editAsignacion', {
      asigned
    });
  });

  app.post('/editAsignacion/:id', isLoggedIn, async (req, res) => {
    const {id} = req.params;
    await Asigned.update({_id: id}, req.body);
    res.redirect('/tablaAsignacion');
  });

  app.get('/deleteAsignacion/:id', isLoggedIn, async(req, res) => {
    const {id} = req.params;
    await Asigned.remove({_id: id});
    res.redirect('/tablaAsignacion');
  });

	// logout
	app.get('/logout', (req, res) => {
		req.logout();
		res.redirect('/');
  });

};


function isLoggedIn (req, res, next) {
	if (req.isAuthenticated()) {
    return next();
	}
	res.redirect('/');
}