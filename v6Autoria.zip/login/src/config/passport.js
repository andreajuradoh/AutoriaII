const LocalStrategy = require('passport-local').Strategy;

const User = require('../app/models/user');
const Ticket = require('../app/models/ticket');

module.exports = function (passport) {
    // required for persistent login sessions
    // passport needs ability to serialize and unserialize users out of session
    passport.serializeUser(function (user, done) {
        done(null, user.id);
    });

    // used to deserialize user
    passport.deserializeUser(function (id, done) {
        User.findById(id, function (err, user) {
        done(err, user);
        });
    }); 

    // Signup
    passport.use('signup', new LocalStrategy({
        // by default, local strategy uses username and password, we will override with email
        usernameField: 'email',
        passwordField: 'password',
        passReqToCallback : true  // allows us to pass back the entire request to the callback
    },
    function (req, email, password, done) {
        User.findOne({'email': email}, function (err, user) {
        if (err) {
            return done(err);
        }
        if (user) {
            return done(null, false, req.flash('signupMessage', 'El correo electrónico ya existe'));
        } else {
            var newUser = new User();
            newUser.firstname = req.body.firstname;
            newUser.lastname = req.body.lastname;
            newUser.city = req.body.city;
            newUser.address = req.body.address;
            newUser.email = email;
            newUser.phone = req.body.phone;
            newUser.username = req.body.username;
            newUser.password = newUser.generateHash(password);
            newUser.save(function (err) {
            if (err) { throw err; }
            return done(null, newUser);
            });
        }
        });
    }));

    // login
    // we are using named strategies since we have one for login and one for signup
    // by default, if there was no name, it would just be called 'local
    passport.use('login', new LocalStrategy({
        usernameField: 'email',
        passwordField: 'password',
        passReqToCallback: true
    },
    function (req, email, password, done) {
        User.findOne({'email': email}, function (err, user) {
        if (err) { return done(err); }
        if (!user) {
            return done(null, false, req.flash('loginMessage', 'Usuario no encontrado'))
        }
        if (!user.validPassword(password)) {
            return done(null, false, req.flash('loginMessage', 'Contraseña incorrecta'));
        }
        return done(null, user);
        });
    }));


    // Tickets
    passport.use('tablaTickets', function (req, done) {
        Ticket.findOne({'priority': priority}, function (err, ticket) {
        if (err) {
            return done(err);
        }
        if (ticket) {
            return done(null, false, req.flash('signupMessage', 'Ese ticket ya existe'));
        } else {
            var newTicket = new Ticket();
            newTicket.subject = req.body.subject;
            newTicket.description = req.body.description;
            newTicket.priority = req.body.priority;
            newTicket.save(function (err) {
            if (err) { throw err; }
            return done(null, newTicket);
            });
        }
        });
    });

}
