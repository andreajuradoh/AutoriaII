const mongoose = require('mongoose');

const asignedSchema = new mongoose.Schema({
    client: {
        type: mongoose.Schema.ObjectId, 
        ref: "User",
        required: true
    },
    subject: {
        type: mongoose.Schema.ObjectId, 
        ref: "Ticket",
        required: true
    },
    priority: { 
        type: mongoose.Schema.ObjectId, 
        ref: "Ticket",
        required: true
     },
    state: { type: String, enum: ['terminado', 'en proceso'], default: 'en proceso' },
    asigned: String,
    created: {type: Date, default: Date.now}
});

// create the model for user and expose it to our app
module.exports = mongoose.model('Asigned', asignedSchema);