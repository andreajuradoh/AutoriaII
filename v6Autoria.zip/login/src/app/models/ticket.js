const mongoose = require('mongoose');

const ticketSchema = new mongoose.Schema({
    subject: String,
    description: String,
    priority: { type: String, enum: ['baja', 'media', 'alta'], default: 'baja' }
});

// create the model for user and expose it to our app
module.exports = mongoose.model('Ticket', ticketSchema);