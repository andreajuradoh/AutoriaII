module.exports = {  
    'url': 'mongodb://localhost/nodelogin'
};